package com.ust.member.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="mbr_cvr")
public class Member_coverage {
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, 
      generator = "SEQUENCE")
	@SequenceGenerator(name = "SEQUENCE", sequenceName = "SEQUENCE", allocationSize = 1)
	@Column(name="cId")
	int cvr_id;
	@Column(name="sbGrpId")
	int sub_grp_id;
	@Column(name="cEftvDt")
	String cvrg_eftv_dt;
	@Column(name="cTrDt")
	String cvrg_tr_dt;
	
	@ManyToOne(cascade= CascadeType.ALL)
	@JoinColumn(name = "mbr_ct_id")
	Member_Contract mbr_ct;

	public Member_coverage() {
		super();
	}

	public Member_coverage(int cvr_id, int sub_grp_id, String cvrg_eftv_dt, String cvrg_tr_dt) {
		super();
		this.cvr_id = cvr_id;
		this.sub_grp_id = sub_grp_id;
		this.cvrg_eftv_dt = cvrg_eftv_dt;
		this.cvrg_tr_dt = cvrg_tr_dt;
	}

	public int getCvr_id() {
		return cvr_id;
	}

	public void setCvr_id(int cvr_id) {
		this.cvr_id = cvr_id;
	}

	public int getSub_grp_id() {
		return sub_grp_id;
	}

	public void setSub_grp_id(int sub_grp_id) {
		this.sub_grp_id = sub_grp_id;
	}

	public String getCvrg_eftv_dt() {
		return cvrg_eftv_dt;
	}

	public void setCvrg_eftv_dt(String cvrg_eftv_dt) {
		this.cvrg_eftv_dt = cvrg_eftv_dt;
	}

	public String getCvrg_tr_dt() {
		return cvrg_tr_dt;
	}

	public void setCvrg_tr_dt(String cvrg_tr_dt) {
		this.cvrg_tr_dt = cvrg_tr_dt;
	}
	

}