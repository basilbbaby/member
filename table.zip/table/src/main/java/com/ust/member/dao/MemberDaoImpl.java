package com.ust.member.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ust.member.model.Member;

@Repository
public class MemberDaoImpl implements MemberDao {

	@Autowired
	SessionFactory SessionFactory;

	public SessionFactory getSessionFactory() {
		return SessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		SessionFactory = sessionFactory;
	}

	@Override
	public List<Member> diplayMember() {

		Session session = SessionFactory.openSession();
		Query query = session.createQuery("from Member");
		List<Member> members = query.list();
		return members;
	}

	@Override
	public Member addMember(Member member) {
		Session session = SessionFactory.openSession();
		session.beginTransaction();
		session.saveOrUpdate(member);
		System.out.println(member.getF_name());
		session.getTransaction().commit();
		return member;
	}

}
